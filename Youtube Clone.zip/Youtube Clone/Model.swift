//
//  Model.swift
//  Youtube Clone
//
//  Created by Bulldozer on 18/03/21.
//

import Foundation

protocol ModelDelegate {
    func videosFetched(_ videos:[Video])
}

class Model {
    //Fungsi untuk membaca link dari constans
    var delegate:ModelDelegate?
    
    func getVideos() {
        //Tahap Pertama
        let url = URL(string: Constants.API_URL)
        //Untuk Menyimpan Data Link
        
        guard url != nil else{
            return
        }
        
        //Tahap Kedua : Get URLSession Object
        let session = URLSession.shared //Pembagian Sesi
        
        //Tahap Ketiga Pembagian Tugas
        let dataTask = session.dataTask(with: url!) { (data, response, error) in
            
            //Cek Jika Error Atau Datanya Kosong
            if error != nil || data == nil {
                return
            }
            
            do {
                
                //Parsing the data into video objects
                let decoder = JSONDecoder()
                decoder.dateDecodingStrategy = .iso8601
                
                let response = try decoder.decode(Response.self, from: data!)
                
                if response.items != nil {
                    DispatchQueue.main.async {
                        
                        //Call the "videosFetched" method of delegate
                        self.delegate?.videosFetched(response.items!)
                    }
                }
                
//               dump(response)
            }
            catch {
                
            }
            
            //Do
            
        }
        
        //Tahap Keempat = Untuk Menjalankan Tugas
        dataTask.resume()
        
    }
}

